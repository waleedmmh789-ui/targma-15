package com.waleed.subgenius.ui.screens

import com.waleed.subgenius.tr

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.ui.platform.LocalContext
import com.waleed.subgenius.AppLang
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.waleed.subgenius.ui.theme.BgDark
import com.waleed.subgenius.ui.theme.Primary
import com.waleed.subgenius.ui.theme.Secondary
import com.waleed.subgenius.ui.theme.SurfaceDark
import com.waleed.subgenius.ui.theme.TextGray
import com.waleed.subgenius.ui.theme.TextWhite

@Composable
fun HomeScreen(
    onPickVideo: (String) -> Unit,
    onOpenProjects: () -> Unit,
    onOpenDownload: () -> Unit,
    onOpenAbout: () -> Unit,
    onOpenPerformance: () -> Unit
) {
    val context = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let { onPickVideo(it.toString()) }
    }
    Box(Modifier.fillMaxSize().background(BgDark)) {
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Top
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = { AppLang.set(context, if (AppLang.isArabic) "en" else "ar") }) {
                    Text(if (AppLang.isArabic) "English" else "العربية", color = TextWhite)
                }
            }
            Spacer(Modifier.height(8.dp))
            Box(
                Modifier.size(100.dp).background(Brush.radialGradient(listOf(Primary, Secondary)), RoundedCornerShape(24.dp)),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Filled.Movie, null, tint = Color.White, modifier = Modifier.size(56.dp)) }
            Spacer(Modifier.height(24.dp))
            Text(tr("عبقري الترجمة", "SubGenius"), fontSize = 32.sp, fontWeight = FontWeight.Bold, color = TextWhite)
            Spacer(Modifier.height(8.dp))
            Text(tr("ترجم فيديوهاتك على الجهاز — بعد تنزيل النماذج", "Subtitle and translate your videos on-device — after downloading the models"), fontSize = 16.sp, color = TextGray, textAlign = TextAlign.Center)
            Spacer(Modifier.height(40.dp))
            Button(
                onClick = { picker.launch("video/*") },
                modifier = Modifier.fillMaxWidth().height(80.dp),
                shape = RoundedCornerShape(20.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Primary)
            ) {
                Icon(Icons.Filled.VideoFile, null, tint = Color.White, modifier = Modifier.size(32.dp))
                Spacer(Modifier.width(12.dp))
                Text(tr("اختر فيديو", "Choose a video"), fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(16.dp))
            OutlinedButton(onClick = onOpenProjects, modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(16.dp)) {
                Icon(Icons.Filled.Folder, null, tint = TextWhite); Spacer(Modifier.width(8.dp)); Text(tr("مشاريعي", "My projects"), color = TextWhite)
            }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = onOpenDownload, modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(16.dp)) {
                Icon(Icons.Filled.CloudDownload, null, tint = TextWhite); Spacer(Modifier.width(8.dp)); Text(tr("تنزيل النماذج", "Download models"), color = TextWhite)
            }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = onOpenPerformance, modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(16.dp)) {
                Icon(Icons.Filled.Speed, null, tint = TextWhite); Spacer(Modifier.width(8.dp)); Text(tr("وضع الأداء", "Performance mode"), color = TextWhite)
            }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = onOpenAbout, modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(16.dp)) {
                Icon(Icons.Filled.Info, null, tint = TextWhite); Spacer(Modifier.width(8.dp)); Text(tr("حول التطبيق والدعم", "About & support"), color = TextWhite)
            }
        }
    }
}
