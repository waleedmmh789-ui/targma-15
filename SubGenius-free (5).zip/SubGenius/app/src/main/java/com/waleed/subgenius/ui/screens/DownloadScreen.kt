package com.waleed.subgenius.ui.screens

import com.waleed.subgenius.tr

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.waleed.subgenius.engine.VoskModelDownloader
import com.waleed.subgenius.engine.WhisperModelDownloader
import com.waleed.subgenius.ui.components.TopBar
import com.waleed.subgenius.ui.theme.BgDark
import com.waleed.subgenius.ui.theme.Secondary
import com.waleed.subgenius.ui.theme.SurfaceDark
import com.waleed.subgenius.ui.theme.TextGray
import com.waleed.subgenius.ui.theme.TextWhite
import kotlinx.coroutines.launch

@Composable
fun DownloadScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val voskStatus = remember {
        mutableStateMapOf<String, String>().apply {
            VoskModelDownloader.models.forEach {
                put(it.lang, if (VoskModelDownloader.getModelPath(context, it.lang) != null) tr("مُنزَّل ✅", "Downloaded ✅") else tr("غير مُنزَّل", "Not downloaded"))
            }
        }
    }
    val whisperStatus = remember {
        mutableStateMapOf<String, String>().apply {
            WhisperModelDownloader.models.forEach {
                put(it.id, if (WhisperModelDownloader.isDownloaded(context, it)) tr("مُنزَّل ✅", "Downloaded ✅") else tr("غير مُنزَّل", "Not downloaded"))
            }
        }
    }
    var working by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().background(BgDark).padding(horizontal = 20.dp).verticalScroll(rememberScrollState())) {
        TopBar(tr("تنزيل النماذج", "Download models"), onBack)
        Spacer(Modifier.height(8.dp))

        Text(tr("Whisper — الأدق للهجات العربية", "Whisper — most accurate for Arabic dialects"), color = TextWhite, fontSize = 16.sp)
        Text(tr("نزّل نموذجاً واحداً على الأقل (يُفضَّل Small). يعمل بدون إنترنت بعد التنزيل.", "Download at least one model (Small recommended). Works offline after download."), color = TextGray, fontSize = 12.sp)
        Spacer(Modifier.height(8.dp))
        WhisperModelDownloader.models.forEach { m ->
            ModelCard("${m.label}", m.size, whisperStatus[m.id] ?: "", !working) {
                scope.launch {
                    working = true
                    val r = WhisperModelDownloader.download(context, m) { whisperStatus[m.id] = tr("جارٍ: $it%", "Downloading: $it%") }
                    working = false
                    r.onSuccess { whisperStatus[m.id] = tr("مُنزَّل ✅", "Downloaded ✅") }.onFailure { whisperStatus[m.id] = tr("فشل: ${it.message}", "Failed: ${it.message}") }
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        Text(tr("Vosk — أسرع وأخف (الفصحى)", "Vosk — faster and lighter (Modern Standard Arabic)"), color = TextWhite, fontSize = 16.sp)
        Spacer(Modifier.height(8.dp))
        VoskModelDownloader.models.forEach { m ->
            ModelCard(m.label, m.size, voskStatus[m.lang] ?: "", !working) {
                scope.launch {
                    working = true
                    val r = VoskModelDownloader.downloadAndUnzip(context, m.lang) { voskStatus[m.lang] = tr("جارٍ: $it%", "Downloading: $it%") }
                    working = false
                    r.onSuccess { voskStatus[m.lang] = tr("مُنزَّل ✅", "Downloaded ✅") }.onFailure { voskStatus[m.lang] = tr("فشل: ${it.message}", "Failed: ${it.message}") }
                }
            }
        }

        Spacer(Modifier.height(8.dp))
        Text(tr("ملاحظة: نماذج الترجمة (ML Kit) تُنزَّل تلقائياً عند أول ترجمة وتحتاج إنترنت.", "Note: ML Kit translation models are downloaded automatically on first translation and need internet."), color = TextGray, fontSize = 12.sp)
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun ModelCard(title: String, size: String, status: String, enabled: Boolean, onDownload: () -> Unit) {
    Card(
        Modifier.fillMaxWidth().padding(bottom = 12.dp), shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(title, color = TextWhite, fontSize = 15.sp)
            Text(tr("$size — يفضَّل Wi-Fi", "$size — Wi-Fi recommended"), color = TextGray, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(status, color = Secondary, fontSize = 12.sp)
                Button(onClick = onDownload, enabled = enabled) { Text(tr("تنزيل", "Download")) }
            }
        }
    }
}
