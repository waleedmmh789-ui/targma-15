package com.waleed.subgenius.ui.screens

import android.app.ActivityManager
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.waleed.subgenius.engine.FFmpegHelper
import com.waleed.subgenius.engine.PerfSettings
import com.waleed.subgenius.engine.Profile
import com.waleed.subgenius.engine.SpeechToText
import com.waleed.subgenius.engine.VoskModelDownloader
import com.waleed.subgenius.engine.WhisperModelDownloader
import com.waleed.subgenius.engine.WhisperSpeech
import com.waleed.subgenius.tr
import com.waleed.subgenius.ui.AppViewModel
import com.waleed.subgenius.ui.components.TopBar
import com.waleed.subgenius.ui.theme.BgDark
import com.waleed.subgenius.ui.theme.ErrRed
import com.waleed.subgenius.ui.theme.Primary
import com.waleed.subgenius.ui.theme.Secondary
import com.waleed.subgenius.ui.theme.TextGray
import com.waleed.subgenius.ui.theme.TextWhite
import android.content.Intent
import android.net.Uri
import androidx.compose.material3.OutlinedTextField
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.input.PasswordVisualTransformation
import com.waleed.subgenius.engine.GeminiAssistant
import com.waleed.subgenius.engine.GeminiKeyStore
import java.util.Locale
import kotlinx.coroutines.launch

private enum class SttEngine { WHISPER, VOSK, GEMINI }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExtractScreen(appViewModel: AppViewModel, onBack: () -> Unit, onDone: () -> Unit, onEdit: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val state by appViewModel.state.collectAsState()
    var engine by remember { mutableStateOf(if (PerfSettings.config.defaultEngineWhisper) SttEngine.WHISPER else SttEngine.VOSK) }
    var direct by remember { mutableStateOf(false) }
    var dialect by remember { mutableStateOf("egy") }
    var geminiKey by remember { mutableStateOf(GeminiKeyStore.loadKey(context)) }
    val clipboard = LocalClipboardManager.current
    val engineScroll = rememberScrollState()
    var modelId by remember { mutableStateOf<String?>(null) }
    var working by remember { mutableStateOf(false) }
    var progress by remember { mutableIntStateOf(0) }
    var stage by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    val hScroll = rememberScrollState()

    val voskLangs = VoskModelDownloader.models.map { it.lang to it.label }
    val langs = if (engine == SttEngine.VOSK) voskLangs else WhisperSpeech.languages
    // نماذج Whisper المنزَّلة (الأعلى دقة أولاً). الاختيار بينها هو أهم وسيلة لتسريع Whisper.
    val downloaded = WhisperModelDownloader.models.filter { WhisperModelDownloader.isDownloaded(context, it) }
    // النموذج الافتراضي يتبع وضع الأداء (Base للضعيفة، Small للمتوسطة والقوية)
    val defaultModel = downloaded.firstOrNull { it.id == PerfSettings.config.whisperModelId }
    val chosen = downloaded.firstOrNull { it.id == modelId } ?: defaultModel ?: downloaded.firstOrNull()

    Column(Modifier.fillMaxSize().background(BgDark).padding(horizontal = 20.dp).verticalScroll(rememberScrollState())) {
        TopBar(tr("استخراج النص", "Extract text"), onBack)
        Spacer(Modifier.height(8.dp))

        Text(
            tr("وضع الأداء: ${PerfSettings.label(PerfSettings.profile)} (يمكن تغييره من الشاشة الرئيسية)", "Performance mode: ${PerfSettings.label(PerfSettings.profile)} (change it from the home screen)"),
            color = TextGray, fontSize = 11.sp
        )
        Spacer(Modifier.height(6.dp))
        Text(tr("محرك التعرف على الكلام:", "Speech recognition engine:"), color = TextGray, fontSize = 12.sp)
        Row(Modifier.horizontalScroll(engineScroll), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = engine == SttEngine.WHISPER, onClick = { engine = SttEngine.WHISPER },
                label = { Text(tr("Whisper — أدق (اللهجات)", "Whisper — more accurate (dialects)")) }, enabled = !working
            )
            FilterChip(
                selected = engine == SttEngine.VOSK,
                onClick = {
                    engine = SttEngine.VOSK
                    if (voskLangs.none { it.first == state.audioLang }) appViewModel.setAudioLang("ar")
                },
                label = { Text(tr("Vosk — أسرع (فصحى)", "Vosk — faster (standard Arabic)")) }, enabled = !working
            )
            FilterChip(
                selected = engine == SttEngine.GEMINI, onClick = { engine = SttEngine.GEMINI },
                label = { Text(tr("Gemini — الأدق للهجات (أونلاين)", "Gemini — best for dialects (online)")) }, enabled = !working
            )
        }

        if (engine == SttEngine.WHISPER && downloaded.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            Text(tr("حجم نموذج Whisper:", "Whisper model size:"), color = TextGray, fontSize = 12.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                downloaded.forEach { m ->
                    FilterChip(
                        selected = chosen?.id == m.id, onClick = { modelId = m.id },
                        label = {
                            Text(
                                if (m.id == "base") tr("Base — أسرع", "Base — faster")
                                else tr("Small — أدق وأبطأ", "Small — more accurate, slower")
                            )
                        },
                        enabled = !working
                    )
                }
            }
            if (PerfSettings.profile == Profile.LIGHT && chosen?.id == "small") {
                Text(
                    tr("⚠️ نموذج Small ثقيل على هاتفك وقد يبطؤ جداً أو يتوقف. جرّب Base أو Vosk.", "⚠️ The Small model is heavy for your phone and may be very slow or crash. Try Base or Vosk."),
                    color = com.waleed.subgenius.ui.theme.WarnYellow, fontSize = 11.sp
                )
            }
            Text(
                tr("Base أسرع وأخف لكنه أقل دقة؛ Small أدق وأبطأ. الفيديو الأقصر من ${PerfSettings.config.whisperSingleClipSec / 60 .coerceAtLeast(1)} دقيقة يُعالج دفعة واحدة لحفظ السياق (حسب وضع الأداء). اختر لغة الكلام يدوياً.",
                   "Base is faster and lighter but less accurate; Small is more accurate and slower. Clips shorter than about ${PerfSettings.config.whisperSingleClipSec / 60 .coerceAtLeast(1)} min are processed in one pass to keep context (depends on performance mode). Select the spoken language manually."),
                color = TextGray, fontSize = 11.sp
            )
        }
        Spacer(Modifier.height(12.dp))

        Text(tr("لغة الكلام في الفيديو:", "Spoken language in the video:"), color = TextGray, fontSize = 12.sp)
        Row(Modifier.horizontalScroll(hScroll), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            langs.forEach { (code, label) ->
                FilterChip(
                    selected = state.audioLang == code, onClick = { appViewModel.setAudioLang(code) },
                    label = { Text(label) }, enabled = !working
                )
            }
        }

        if (engine == SttEngine.GEMINI) {
            Spacer(Modifier.height(12.dp))
            if (state.audioLang == "ar") {
                Text(tr("اللهجة المنطوقة:", "Spoken dialect:"), color = TextGray, fontSize = 12.sp)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(
                        "egy" to tr("مصرية", "Egyptian"), "tn" to tr("تونسية", "Tunisian"),
                        "msa" to tr("فصحى", "Standard (MSA)"), "auto" to tr("أي لهجة", "Any dialect")
                    ).forEach { (id, label) ->
                        FilterChip(selected = dialect == id, onClick = { dialect = id }, label = { Text(label) }, enabled = !working)
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
            OutlinedTextField(
                value = geminiKey,
                onValueChange = { geminiKey = it.trim(); GeminiKeyStore.saveKey(context, geminiKey) },
                label = { Text(tr("مفتاح Gemini API", "Gemini API key")) },
                visualTransformation = PasswordVisualTransformation(), singleLine = true,
                modifier = Modifier.fillMaxWidth(), enabled = !working
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                OutlinedButton(
                    onClick = { clipboard.getText()?.text?.let { geminiKey = it.trim(); GeminiKeyStore.saveKey(context, geminiKey) } },
                    modifier = Modifier.weight(1f), enabled = !working
                ) { Text(tr("لصق من الحافظة", "Paste from clipboard"), fontSize = 12.sp) }
                OutlinedButton(
                    onClick = {
                        try { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/apikey")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
                    },
                    modifier = Modifier.weight(1f), enabled = !working
                ) { Text(tr("الحصول على مفتاح", "Get a key"), fontSize = 12.sp) }
            }
            Text(
                tr("الحصول على المفتاح: افتح aistudio.google.com/apikey وسجّل بحساب Google ← Create API key ← انسخه والصقه هنا (يُحفظ مشفّراً ولا يلزم إدخاله مرة أخرى). أي مفتاح يعمل مع كل نماذج Gemini المتاحة له.",
                   "Getting a key: open aistudio.google.com/apikey, sign in with Google → Create API key → copy and paste it here (saved encrypted, no need to re-enter). Any key works with every Gemini model available to it."),
                color = TextGray, fontSize = 11.sp
            )
            Text(
                tr("⚠️ خصوصية: يُرسل صوت الفيديو (مقاطع قصيرة) إلى خوادم Google لتحويله إلى نص. لا تستخدمه لمحتوى حساس، واستخدم Vosk أو Whisper للمعالجة المحلية. الأزمنة تقريبية، فراجع النص بالمحرر.",
                   "⚠️ Privacy: the video's audio (short clips) is sent to Google servers to be transcribed. Don't use it for sensitive content; use Vosk or Whisper for on-device processing. Timings are approximate, so review the text in the editor."),
                color = com.waleed.subgenius.ui.theme.WarnYellow, fontSize = 11.sp
            )
        }

        if (engine == SttEngine.WHISPER && state.audioLang != "en") {
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(tr("ترجمة مباشرة إلى الإنجليزية", "Translate directly to English"), color = TextWhite, fontSize = 14.sp)
                    Text(
                        tr("أدق للهجات: يترجم من الصوت مباشرة، ثم يمكنك ترجمة الإنجليزية إلى أي لغة أخرى.",
                           "More accurate for dialects: translates straight from the audio, then you can translate the English into any other language."),
                        color = TextGray, fontSize = 11.sp
                    )
                }
                Switch(checked = direct, onCheckedChange = { direct = it }, enabled = !working)
            }
        }
        Spacer(Modifier.height(16.dp))

        if (!working && state.originalSegments.isEmpty()) {
            Button(
                onClick = {
                    scope.launch {
                        error = null
                        val file = state.videoFile ?: run { error = tr("لا يوجد فيديو", "No video"); return@launch }
                        val lang = state.audioLang
                        val useDirect = engine == SttEngine.WHISPER && direct && lang != "en"
                        if (engine == SttEngine.GEMINI && geminiKey.isBlank()) {
                            error = tr("أدخل مفتاح Gemini API أولاً (زر «الحصول على مفتاح»).", "Enter a Gemini API key first (use 'Get a key').")
                            return@launch
                        }
                        val modelPath = when (engine) {
                            SttEngine.WHISPER -> chosen?.let { WhisperModelDownloader.file(context, it).absolutePath }
                            SttEngine.VOSK -> VoskModelDownloader.getModelPath(context, lang)
                            SttEngine.GEMINI -> "gemini"
                        }
                        if (modelPath == null) {
                            error = tr("نموذج هذا المحرك غير مُنزَّل. نزّله من «تنزيل النماذج».", "This engine's model is not downloaded. Get it from 'Download models'.")
                            return@launch
                        }
                        working = true; progress = 0
                        val audio = FFmpegHelper.extractAudio(context, file) { progress = it / 10; stage = tr("استخراج الصوت", "Extracting audio") }
                            .getOrElse { error = it.message; working = false; return@launch }
                        val r = when (engine) {
                            SttEngine.WHISPER -> WhisperSpeech.transcribe(context, audio, modelPath, lang, useDirect) {
                                progress = 10 + it * 9 / 10; stage = tr("التعرف على الكلام (Whisper)", "Recognizing speech (Whisper)")
                            }
                            SttEngine.GEMINI -> GeminiAssistant.transcribeAudio(
                                geminiKey, GeminiKeyStore.loadModel(context), geminiLanguageName(lang, dialect), audio
                            ) {
                                progress = 10 + it * 9 / 10; stage = tr("التعرف على الكلام (Gemini)", "Recognizing speech (Gemini)")
                            }
                            SttEngine.VOSK -> SpeechToText.transcribe(audio, modelPath) {
                                progress = 10 + it * 9 / 10; stage = tr("التعرف على الكلام (Vosk)", "Recognizing speech (Vosk)")
                            }
                        }
                        audio.delete(); working = false
                        r.onSuccess {
                            if (it.isEmpty()) error = tr("لم يُكتشف أي كلام", "No speech detected")
                            else appViewModel.setOriginalSegments(it, if (useDirect) "en" else null)
                        }.onFailure { error = it.message }
                    }
                },
                modifier = Modifier.fillMaxWidth().height(64.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Primary)
            ) { Text(tr("بدء الاستخراج", "Start extraction"), fontSize = 16.sp) }
        }
        if (working) {
            LinearProgressIndicator(progress = { progress / 100f }, modifier = Modifier.fillMaxWidth(), color = Primary)
            Text("$stage ($progress%)", color = TextGray, fontSize = 14.sp)
            if (engine == SttEngine.WHISPER) {
                Text(tr("اترك التطبيق مفتوحًا أثناء المعالجة. إذا كانت الكلمات غير دقيقة، أوقف «الترجمة المباشرة إلى الإنجليزية» أولًا للحصول على النص العربي الأصلي.", "Keep the app open while processing. If words are inaccurate, turn off ‘Translate directly to English’ first to get the original Arabic transcript."), color = TextGray, fontSize = 11.sp)
            }
        }
        error?.let { Text(it, color = ErrRed, fontSize = 14.sp) }

        if (state.originalSegments.isNotEmpty()) {
            Text(
                tr("عدد المقاطع: ${state.originalSegments.size} • لغة النص: ${state.sourceLang}", "Segments: ${state.originalSegments.size} • Text language: ${state.sourceLang}"),
                color = TextWhite
            )
            Spacer(Modifier.height(8.dp))
            state.originalSegments.forEach { Text(it.text, color = TextWhite, fontSize = 14.sp, modifier = Modifier.padding(vertical = 2.dp)) }
            Spacer(Modifier.height(16.dp))
            OutlinedButton(onClick = onEdit, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                Text(tr("✏️ تعديل / نسخ / قص / لصق النص", "✏️ Edit / copy / cut / paste text"))
            }
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = onDone, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Secondary)
            ) { Text(tr("متابعة إلى الترجمة", "Continue to translation")) }
            TextButton(onClick = { appViewModel.clearSegments() }, modifier = Modifier.fillMaxWidth()) { Text(tr("إعادة الاستخراج", "Re-extract")) }
        }
        Spacer(Modifier.height(32.dp))
    }
}

private fun geminiLanguageName(lang: String, dialect: String): String =
    if (lang == "ar") when (dialect) {
        "egy" -> "Egyptian Arabic (colloquial dialect)"
        "tn" -> "Tunisian Arabic (Derja, colloquial dialect)"
        "msa" -> "Modern Standard Arabic"
        else -> "Arabic (any dialect, keep it as spoken)"
    } else Locale.forLanguageTag(lang).getDisplayLanguage(Locale.ENGLISH)
