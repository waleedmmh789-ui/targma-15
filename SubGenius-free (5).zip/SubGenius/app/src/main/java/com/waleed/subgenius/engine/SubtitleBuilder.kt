package com.waleed.subgenius.engine

import android.content.Context
import java.io.File
import java.util.Locale

object SubtitleBuilder {
    fun buildAss(context: Context, segments: List<SpeechSegment>, style: SubtitleStyle = SubtitleStyle()): Result<File> = try {
        val file = File(context.cacheDir, "subs_${System.currentTimeMillis()}.ass")
        val sb = StringBuilder()
        sb.appendLine("[Script Info]")
        sb.appendLine("ScriptType: v4.00+")
        sb.appendLine("PlayResX: 384")
        sb.appendLine("PlayResY: 288")
        sb.appendLine("WrapStyle: 0")
        sb.appendLine("ScaledBorderAndShadow: yes")
        sb.appendLine()
        sb.appendLine("[V4+ Styles]")
        sb.appendLine("Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding")
        sb.appendLine("Style: Default,${style.fontName},${style.fontSize},${style.primaryColor},&H000000FF,${style.backColor},${style.backColor},0,0,0,0,100,100,0,0,${style.borderStyle},${style.outline},0,2,10,10,${style.marginV},1")
        sb.appendLine()
        sb.appendLine("[Events]")
        sb.appendLine("Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text")
        segments.forEach { seg ->
            val text = seg.text.replace("{", "(").replace("}", ")").replace("\n", "\\N")
            sb.appendLine("Dialogue: 0,${formatTime(seg.startMs)},${formatTime(seg.endMs)},Default,,0,0,0,,$text")
        }
        file.writeText(sb.toString())
        Result.success(file)
    } catch (e: Exception) { Result.failure(e) }

    private fun formatTime(ms: Long): String {
        val total = ms / 10   // سنتي ثانية
        val cs = total % 100
        val s = (total / 100) % 60
        val m = (total / 6000) % 60
        val h = total / 360000
        return String.format(Locale.US, "%d:%02d:%02d.%02d", h, m, s, cs)
    }
}
