package com.waleed.subgenius.engine

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File
import java.io.RandomAccessFile
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import kotlin.coroutines.coroutineContext
import kotlin.math.abs

object SpeechToText {
    private const val MAX_WORDS = 7                 // أقصى عدد كلمات في سطر ترجمة
    private const val BYTES_PER_SEC = 16000 * 2     // PCM s16le 16kHz mono
    private const val PARALLEL_MIN_SEC = 60         // الملفات الأقصر تُعالج بخيط واحد
    private const val CHUNK_BYTES = 16384           // أكبر من 4096 لتقليل استدعاءات JNI

    // ---- تخزين النموذج مؤقتاً: تحميله يستغرق عدة ثوانٍ ----
    private var cachedPath: String? = null
    private var cachedModel: Model? = null
    private val active = AtomicInteger(0)

    @Synchronized
    private fun getModel(path: String): Model {
        cachedModel?.let { if (cachedPath == path) return it }
        runCatching { cachedModel?.close() }
        return Model(path).also { cachedModel = it; cachedPath = path }
    }

    /** يُستدعى عند الذهاب للخلفية لتحرير مئات الميغابايت (فقط إن لم تكن هناك معالجة جارية) */
    @Synchronized
    fun releaseModel() {
        if (active.get() == 0) {
            runCatching { cachedModel?.close() }
            cachedModel = null; cachedPath = null
        }
    }

    /** pcmFile: صوت خام s16le 16kHz mono */
    suspend fun transcribe(
        pcmFile: File, modelPath: String, onProgress: (Int) -> Unit = {}
    ): Result<List<SpeechSegment>> = withContext(Dispatchers.Default) {
        active.incrementAndGet()
        try {
            val model = getModel(modelPath)
            val total = pcmFile.length()
            val workers = if (total / BYTES_PER_SEC < PARALLEL_MIN_SEC) 1
            else PerfSettings.config.voskWorkers
            val ranges = splitRanges(pcmFile, total, workers)

            val done = AtomicLong(0)
            val lastPct = AtomicInteger(-1)
            val onBytes: (Int) -> Unit = { n ->
                val pct = ((done.addAndGet(n.toLong()) * 100) / total).toInt().coerceIn(0, 99)
                val prev = lastPct.get()
                if (pct > prev && lastPct.compareAndSet(prev, pct)) onProgress(pct)
            }

            val parts = coroutineScope {
                ranges.map { (s, e) ->
                    async { transcribeRange(pcmFile, model, s, e, s * 1000 / BYTES_PER_SEC, onBytes) }
                }.awaitAll()
            }
            onProgress(100)
            Result.success(parts.flatten().sortedBy { it.startMs })
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            Result.failure(e)
        } finally {
            active.decrementAndGet()
            if (PerfSettings.config.releaseModelsAfterUse) releaseModel()
        }
    }

    private suspend fun transcribeRange(
        file: File, model: Model, startByte: Long, endByte: Long, offsetMs: Long, onBytes: (Int) -> Unit
    ): List<SpeechSegment> {
        val out = mutableListOf<SpeechSegment>()
        val rec = Recognizer(model, 16000.0f)
        try {
            rec.setWords(true)
            RandomAccessFile(file, "r").use { raf ->
                raf.seek(startByte)
                val buf = ByteArray(CHUNK_BYTES)
                var remaining = endByte - startByte
                while (remaining > 0) {
                    coroutineContext.ensureActive()
                    val n = raf.read(buf, 0, minOf(buf.size.toLong(), remaining).toInt())
                    if (n <= 0) break
                    if (rec.acceptWaveForm(buf, n)) parse(rec.result, out, offsetMs)
                    remaining -= n
                    onBytes(n)
                }
                parse(rec.finalResult, out, offsetMs)
            }
        } finally {
            runCatching { rec.close() }
        }
        return out
    }

    /** يقسم الملف إلى مقاطع متساوية تقريباً، ويختار نقطة القطع عند أهدأ لحظة (±3 ثوانٍ) لتقليل قطع الكلمات */
    private fun splitRanges(file: File, total: Long, workers: Int): List<Pair<Long, Long>> {
        if (workers <= 1) return listOf(0L to total)
        val cuts = mutableListOf(0L)
        for (i in 1 until workers) cuts += quietPoint(file, total * i / workers, total)
        cuts += total
        return cuts.zipWithNext()
    }

    private fun quietPoint(file: File, target: Long, total: Long): Long {
        val frame = 1600                                  // 50ms
        val window = 3L * BYTES_PER_SEC
        val from = ((target - window).coerceAtLeast(0)) / 2 * 2
        val to = (target + window).coerceAtMost(total)
        val len = (to - from).toInt()
        if (len < frame * 2) return target / 2 * 2
        val data = ByteArray(len)
        RandomAccessFile(file, "r").use { it.seek(from); it.readFully(data) }
        var best = Long.MAX_VALUE
        var bestPos = target
        var pos = 0
        while (pos + frame <= len) {
            var sum = 0L
            var i = pos
            while (i < pos + frame) {
                val s = (data[i].toInt() and 0xFF) or (data[i + 1].toInt() shl 8)
                sum += abs(s)
                i += 2
            }
            if (sum < best) { best = sum; bestPos = from + pos + frame / 2 }
            pos += frame
        }
        return bestPos / 2 * 2
    }

    private fun parse(json: String, out: MutableList<SpeechSegment>, offsetMs: Long) {
        try {
            val obj = JSONObject(json)
            val text = obj.optString("text", "").trim()
            if (text.isEmpty()) return
            val arr = obj.optJSONArray("result")
            if (arr == null || arr.length() == 0) {
                val lastEnd = out.lastOrNull()?.endMs ?: offsetMs
                out.add(SpeechSegment(text, lastEnd, lastEnd + 2000))
                return
            }
            var i = 0
            while (i < arr.length()) {
                val end = minOf(i + MAX_WORDS, arr.length())
                val words = (i until end).joinToString(" ") { arr.getJSONObject(it).optString("word") }
                val start = offsetMs + (arr.getJSONObject(i).optDouble("start") * 1000).toLong()
                val stop = offsetMs + (arr.getJSONObject(end - 1).optDouble("end") * 1000).toLong()
                out.add(SpeechSegment(words, start, stop))
                i = end
            }
        } catch (_: Exception) {}
    }
}
