package com.waleed.subgenius.engine

import com.waleed.subgenius.tr

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

data class WhisperModelInfo(
    val id: String, private val labelAr: String, private val labelEn: String, val fileName: String,
    val url: String, val size: String, val minBytes: Long
) {
    val label: String get() = tr(labelAr, labelEn)
}

object WhisperModelDownloader {
    private const val BASE = "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/"

    /** الأول هو الأفضل دقةً ويُفضَّل تلقائياً إن كان مُنزَّلاً */
    val models = listOf(
        WhisperModelInfo("small", "Small — دقة أعلى (موصى به للهجات)", "Small — higher accuracy (recommended for dialects)", "ggml-small.bin", BASE + "ggml-small.bin", "~466MB", 400_000_000L),
        WhisperModelInfo("base", "Base — أسرع وأقل دقة", "Base — faster, less accurate", "ggml-base.bin", BASE + "ggml-base.bin", "~142MB", 120_000_000L)
    )

    private fun dir(context: Context) = File(context.filesDir, "whisper").apply { mkdirs() }
    fun file(context: Context, m: WhisperModelInfo) = File(dir(context), m.fileName)
    fun isDownloaded(context: Context, m: WhisperModelInfo) =
        file(context, m).let { it.exists() && it.length() >= m.minBytes }

    fun bestModelPath(context: Context): String? =
        models.firstOrNull { isDownloaded(context, it) }?.let { file(context, it).absolutePath }

    suspend fun download(context: Context, m: WhisperModelInfo, onProgress: (Int) -> Unit): Result<Unit> =
        withContext(Dispatchers.IO) {
            val part = File(dir(context), m.fileName + ".part")
            try {
                val conn = URL(m.url).openConnection() as HttpURLConnection
                conn.connectTimeout = 20000; conn.readTimeout = 30000
                conn.connect()
                if (conn.responseCode != 200) throw Exception(tr("HTTP ${conn.responseCode} — تحقق من رابط النموذج", "HTTP ${conn.responseCode} — check the model link"))
                val total = conn.contentLengthLong
                if (total > 0 && context.filesDir.usableSpace < total + 50_000_000L)
                    throw Exception(tr("المساحة غير كافية", "Not enough storage space"))
                var done = 0L
                var last = -1
                conn.inputStream.use { input ->
                    FileOutputStream(part).use { out ->
                        val buf = ByteArray(65536); var n: Int
                        while (input.read(buf).also { n = it } != -1) {
                            out.write(buf, 0, n); done += n
                            if (total > 0) {
                                val pct = ((done * 100) / total).toInt().coerceIn(0, 99)
                                if (pct != last) { last = pct; onProgress(pct) }
                            }
                        }
                    }
                }
                if (part.length() < m.minBytes) throw Exception(tr("الملف ناقص، أعد المحاولة", "Incomplete file, try again"))
                val target = file(context, m)
                if (target.exists()) target.delete()
                if (!part.renameTo(target)) throw Exception(tr("تعذّر حفظ النموذج", "Could not save the model"))
                onProgress(100)
                Result.success(Unit)
            } catch (e: Exception) {
                runCatching { part.delete() }
                Result.failure(e)
            }
        }
}
