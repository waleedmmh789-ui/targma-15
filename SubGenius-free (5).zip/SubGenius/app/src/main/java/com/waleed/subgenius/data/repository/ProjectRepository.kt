package com.waleed.subgenius.data.repository

import android.content.Context
import com.waleed.subgenius.data.db.AppDatabase
import com.waleed.subgenius.data.model.Project
import kotlinx.coroutines.flow.Flow

class ProjectRepository(context: Context) {
    private val dao = AppDatabase.get(context).projectDao()
    fun getAll(): Flow<List<Project>> = dao.getAll()
    suspend fun getById(id: Long): Project? = dao.getById(id)
    suspend fun insert(project: Project): Long = dao.insert(project)
    suspend fun update(project: Project) = dao.update(project)
    suspend fun delete(project: Project) = dao.delete(project)
    suspend fun deleteAll() = dao.deleteAll()
}
