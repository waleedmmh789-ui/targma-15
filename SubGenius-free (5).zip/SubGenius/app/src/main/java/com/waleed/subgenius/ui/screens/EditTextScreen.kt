package com.waleed.subgenius.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.waleed.subgenius.engine.SpeechSegment
import com.waleed.subgenius.tr
import com.waleed.subgenius.ui.AppViewModel
import com.waleed.subgenius.ui.components.TopBar
import com.waleed.subgenius.ui.theme.BgDark
import com.waleed.subgenius.ui.theme.ErrRed
import com.waleed.subgenius.ui.theme.OkGreen
import com.waleed.subgenius.ui.theme.Secondary
import com.waleed.subgenius.ui.theme.TextGray
import com.waleed.subgenius.ui.theme.WarnYellow

/** تعديل النص (أو الترجمة) سطراً بسطر: نسخ / قص / لصق للكل أو لكل سطر */
@Composable
fun EditTextScreen(appViewModel: AppViewModel, translated: Boolean, onBack: () -> Unit) {
    val clipboard = LocalClipboardManager.current
    val state by appViewModel.state.collectAsState()
    val segments = if (translated) state.translatedSegments else state.originalSegments
    var message by remember { mutableStateOf<String?>(null) }
    var pending by remember { mutableStateOf<List<String>?>(null) }

    fun copyAll() {
        clipboard.setText(AnnotatedString(segments.joinToString("\n") { it.text }))
    }

    Column(Modifier.fillMaxSize().background(BgDark).padding(horizontal = 20.dp)) {
        TopBar(if (translated) tr("تعديل الترجمة", "Edit translation") else tr("تعديل النص المستخرج", "Edit extracted text"), onBack)

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            OutlinedButton(
                onClick = {
                    copyAll()
                    message = tr("تم نسخ ${segments.size} سطراً ✅", "Copied ${segments.size} lines ✅"); pending = null
                },
                modifier = Modifier.weight(1f)
            ) { Icon(Icons.Filled.ContentCopy, null); Spacer(Modifier.width(6.dp)); Text(tr("نسخ الكل", "Copy all")) }

            OutlinedButton(
                onClick = {
                    copyAll()
                    appViewModel.replaceTexts(translated, List(segments.size) { "" })
                    message = tr("تم قص ${segments.size} سطراً. عالجه ثم الصقه هنا ✅", "Cut ${segments.size} lines. Fix them, then paste back here ✅"); pending = null
                },
                modifier = Modifier.weight(1f)
            ) { Icon(Icons.Filled.ContentCut, null); Spacer(Modifier.width(6.dp)); Text(tr("قص الكل", "Cut all")) }
        }
        OutlinedButton(
            onClick = {
                val lines = clipboard.getText()?.text.orEmpty().split("\n").map { it.trim() }.filter { it.isNotEmpty() }
                when {
                    lines.isEmpty() -> { message = tr("الحافظة فارغة", "Clipboard is empty"); pending = null }
                    lines.size == segments.size -> {
                        appViewModel.replaceTexts(translated, lines)
                        message = tr("تم اللصق ✅", "Pasted ✅"); pending = null
                    }
                    else -> {
                        pending = lines
                        message = tr("عدد الأسطر (${lines.size}) لا يطابق عدد المقاطع (${segments.size}).", "Line count (${lines.size}) does not match segment count (${segments.size}).")
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Icon(Icons.Filled.ContentPaste, null); Spacer(Modifier.width(6.dp)); Text(tr("لصق الكل (استبدال)", "Paste all (replace)")) }

        Text(
            tr("نصيحة: انسخ أو اقصّ الكل، صحّحه في أي تطبيق، ثم الصقه هنا. يُفضّل أن يبقى عدد الأسطر كما هو، وإلا يمكنك التوزيع التلقائي.",
               "Tip: copy or cut all, fix it in any app, then paste it back here. Keep the number of lines the same, or use auto-distribute."),
            color = TextGray, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp)
        )
        message?.let { Text(it, color = if (it.contains("✅")) OkGreen else WarnYellow, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp)) }
        pending?.let { lines ->
            Button(
                onClick = {
                    appViewModel.replaceTexts(translated, redistribute(lines.joinToString(" "), segments))
                    message = tr("تم التوزيع التلقائي حسب عدد الكلمات ✅", "Auto-distributed by word count ✅"); pending = null
                },
                modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Secondary)
            ) { Text(tr("توزيع تلقائي حسب عدد الكلمات", "Auto-distribute by word count")) }
        }
        Spacer(Modifier.height(8.dp))

        if (segments.isEmpty()) {
            Text(tr("لا يوجد نص للتعديل.", "No text to edit."), color = TextGray)
        } else {
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                itemsIndexed(segments) { i, seg ->
                    SegmentRow(
                        index = i, seg = seg,
                        onChange = { appViewModel.updateText(translated, i, it) },
                        onCopy = {
                            clipboard.setText(AnnotatedString(seg.text))
                            message = tr("تم نسخ السطر ${i + 1} ✅", "Copied line ${i + 1} ✅")
                        },
                        onCut = {
                            clipboard.setText(AnnotatedString(seg.text))
                            appViewModel.updateText(translated, i, "")
                            message = tr("تم قص السطر ${i + 1} ✅", "Cut line ${i + 1} ✅")
                        },
                        onPaste = {
                            val t = clipboard.getText()?.text?.replace("\n", " ")?.trim().orEmpty()
                            if (t.isNotEmpty()) {
                                appViewModel.updateText(translated, i, t)
                                message = tr("تم لصق السطر ${i + 1} ✅", "Pasted line ${i + 1} ✅")
                            }
                        },
                        onDelete = { appViewModel.deleteSegment(translated, i) }
                    )
                }
                item { Spacer(Modifier.height(24.dp)) }
            }
        }
    }
}

@Composable
private fun SegmentRow(
    index: Int, seg: SpeechSegment, onChange: (String) -> Unit,
    onCopy: () -> Unit, onCut: () -> Unit, onPaste: () -> Unit, onDelete: () -> Unit
) {
    var tf by remember { mutableStateOf(TextFieldValue(seg.text)) }
    LaunchedEffect(seg.text) { if (tf.text != seg.text) tf = TextFieldValue(seg.text) }
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("${index + 1} • ${fmt(seg.startMs)}", color = TextGray, fontSize = 11.sp, modifier = Modifier.weight(1f))
            IconButton(onClick = onCopy) { Icon(Icons.Filled.ContentCopy, contentDescription = tr("نسخ السطر", "Copy line"), tint = TextGray) }
            IconButton(onClick = onCut) { Icon(Icons.Filled.ContentCut, contentDescription = tr("قص السطر", "Cut line"), tint = TextGray) }
            IconButton(onClick = onPaste) { Icon(Icons.Filled.ContentPaste, contentDescription = tr("لصق في السطر", "Paste into line"), tint = TextGray) }
            IconButton(onClick = onDelete) { Icon(Icons.Filled.Delete, contentDescription = tr("حذف المقطع", "Delete segment"), tint = ErrRed) }
        }
        OutlinedTextField(
            value = tf,
            onValueChange = { tf = it; if (it.text != seg.text) onChange(it.text) },
            modifier = Modifier.fillMaxWidth()
        )
    }
}

private fun fmt(ms: Long): String = "%d:%02d".format(ms / 60000, (ms / 1000) % 60)

/** يوزّع نصاً لصقه المستخدم على المقاطع بنسبة عدد كلمات كل مقطع أصلاً */
private fun redistribute(text: String, segs: List<SpeechSegment>): List<String> {
    val ws = Regex("\\s+")
    val words = text.split(ws).filter { it.isNotEmpty() }
    val weights = segs.map { s -> s.text.split(ws).count { it.isNotEmpty() }.coerceAtLeast(1) }
    val total = weights.sum()
    var cum = 0
    var prev = 0
    return weights.mapIndexed { i, w ->
        cum += w
        val end = if (i == weights.lastIndex) words.size else Math.round(cum.toDouble() / total * words.size).toInt()
        val to = maxOf(end, prev)
        val part = words.subList(prev, to).joinToString(" ")
        prev = to
        part
    }
}
