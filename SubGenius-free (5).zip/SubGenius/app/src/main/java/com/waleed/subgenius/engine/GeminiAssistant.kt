package com.waleed.subgenius.engine

import android.util.Base64
import com.waleed.subgenius.tr
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.coroutines.coroutineContext

class GeminiHttpException(val code: Int, message: String) : Exception(message)

/**
 * Gemini عبر REST بمفتاح المستخدم. أي مفتاح صالح يعمل مع كل نماذج Gemini المتاحة له:
 * يجلب التطبيق قائمة النماذج من حسابه تلقائياً، ويجرّب نموذجاً بعد آخر إن لم يتوفر أحدها.
 */
object GeminiAssistant {
    private const val BASE = "https://generativelanguage.googleapis.com/v1beta"
    // نماذج لا تصلح لتصحيح/ترجمة النص
    private val EXCLUDE = listOf("image", "tts", "embedding", "live", "audio", "robotics", "computer", "imagen", "veo", "aqa", "learnlm")

    /** آخر نموذج نجح فعلاً (للعرض في الواجهة) */
    @Volatile var lastModelUsed: String? = null
        private set

    // ---------------- قائمة النماذج ----------------
    suspend fun listModels(apiKey: String): Result<List<String>> = withContext(Dispatchers.IO) {
        try {
            val key = apiKey.trim()
            require(key.isNotBlank()) { tr("أدخل مفتاح Gemini API أولاً", "Enter a Gemini API key first") }
            val found = mutableListOf<String>()
            var token: String? = null
            do {
                val url = "$BASE/models?pageSize=100" + (token?.let { "&pageToken=" + java.net.URLEncoder.encode(it, "UTF-8") } ?: "")
                val obj = JSONObject(httpGet(url, key))
                val arr = obj.optJSONArray("models") ?: JSONArray()
                for (i in 0 until arr.length()) {
                    val m = arr.optJSONObject(i) ?: continue
                    val id = m.optString("name").removePrefix("models/")
                    val methods = m.optJSONArray("supportedGenerationMethods")
                    var canGenerate = false
                    if (methods != null) for (j in 0 until methods.length()) if (methods.optString(j) == "generateContent") canGenerate = true
                    if (id.startsWith("gemini") && canGenerate && EXCLUDE.none { id.contains(it) }) found += id
                }
                token = obj.optString("nextPageToken", "").ifBlank { null }
            } while (token != null)
            Result.success(rank(found.distinct()))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            Result.failure(e)
        }
    }

    /** الأحدث والمستقر أولاً؛ flash قبل flash-lite قبل pro */
    private fun rank(models: List<String>): List<String> {
        fun version(m: String) = Regex("gemini-(\\d+(?:\\.\\d+)?)").find(m)?.groupValues?.get(1)?.toDoubleOrNull() ?: 0.0
        fun tier(m: String) = when {
            m.contains("flash-lite") -> 1
            m.contains("flash") -> 0
            m.contains("pro") -> 2
            else -> 3
        }
        fun unstable(m: String) = if (Regex("preview|exp|latest|-\\d{2}-\\d{4}").containsMatchIn(m)) 1 else 0
        return models.sortedWith(compareBy<String>({ tier(it) == 3 }, { unstable(it) }, { -version(it) }, { tier(it) }, { it }))
    }

    // ---------------- الميزات ----------------
    suspend fun correctTranscript(
        apiKey: String, preferredModel: String?, sourceLanguage: String,
        segments: List<SpeechSegment>, onProgress: (Int) -> Unit = {}
    ): Result<List<SpeechSegment>> = processSegments(apiKey, preferredModel, sourceLanguage, "correct", segments, "", onProgress)

    suspend fun translateSegments(
        apiKey: String, preferredModel: String?, sourceLanguage: String, targetLanguage: String,
        segments: List<SpeechSegment>, onProgress: (Int) -> Unit = {}
    ): Result<List<SpeechSegment>> = processSegments(apiKey, preferredModel, sourceLanguage, "translate", segments, targetLanguage, onProgress)

    private suspend fun processSegments(
        apiKey: String, preferred: String?, source: String, mode: String,
        segments: List<SpeechSegment>, target: String, onProgress: (Int) -> Unit
    ): Result<List<SpeechSegment>> = withContext(Dispatchers.IO) {
        try {
            val key = apiKey.trim()
            require(key.isNotBlank()) { tr("أدخل مفتاح Gemini API أولاً", "Enter a Gemini API key first") }
            if (segments.isEmpty()) return@withContext Result.success(emptyList())
            val chain = buildChain(key, preferred)
            val output = segments.toMutableList()
            val batches = segments.indices.toList().chunked(10)
            var start = 0
            batches.forEachIndexed { batchIndex, indexes ->
                val input = JSONArray()
                indexes.forEach { i -> input.put(JSONObject().put("i", i).put("text", segments[i].text)) }
                val instruction = if (mode == "correct") {
                    "Correct speech-recognition mistakes in this transcript. Source language: $source. " +
                    "For Egyptian Arabic, preserve Egyptian dialect and colloquial wording; use context to fix likely misheard words. " +
                    "Do not translate, summarize, invent content, or change speaker intent. Keep each item separate. "
                } else {
                    "Translate each subtitle segment from $source to $target. Preserve meaning, tone, names, and dialogue context. " +
                    "Keep each item separate and concise for subtitles. Return only the translated text for each item. "
                }
                val prompt = instruction + "Return valid JSON only in this exact shape: {\"items\":[{\"i\":0,\"text\":\"...\"}]}. " +
                    "Return one item for every input index, preserve all indices, and do not add markdown. Input: " + input.toString()

                val (parsed, usedIdx) = callWithFallback(key, chain, start, JSONArray().put(JSONObject().put("text", prompt)))
                start = usedIdx
                val items = parsed.optJSONArray("items") ?: throw IllegalStateException("Gemini response did not contain items")
                val byIndex = mutableMapOf<Int, String>()
                for (j in 0 until items.length()) {
                    val item = items.optJSONObject(j) ?: continue
                    val idx = item.optInt("i", -1)
                    val value = item.optString("text", "").trim()
                    if (idx in indexes && value.isNotBlank()) byIndex[idx] = value
                }
                indexes.forEach { i ->
                    output[i] = segments[i].copy(text = byIndex[i] ?: segments[i].text)   // عند السقط يبقى النص كما هو
                }
                onProgress(((batchIndex + 1) * 100) / batches.size)
            }
            Result.success(output)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            Result.failure(e)
        }
    }

    /** النموذج المفضّل (إن حدّده المستخدم) ثم النماذج المتاحة لمفتاحه بالترتيب (حتى 5) */
    private suspend fun buildChain(key: String, preferred: String?): List<String> {
        val pref = preferred?.trim()?.removePrefix("models/")?.takeIf { it.isNotEmpty() && it != "auto" }
        val listed = listModels(key)
        val models = listed.getOrNull().orEmpty()
        if (pref == null && models.isEmpty()) {
            throw listed.exceptionOrNull() ?: IllegalStateException(tr("لا توجد نماذج Gemini متاحة لهذا المفتاح", "No Gemini models are available for this key"))
        }
        return (listOfNotNull(pref) + models).distinct().take(5)
    }

    /** يجرّب النماذج بالترتيب؛ عند 429 ينتظر ويعيد؛ عند 404/503/غيرها ينتقل للنموذج التالي */
    private suspend fun callWithFallback(key: String, chain: List<String>, start: Int, parts: JSONArray): Pair<JSONObject, Int> {
        var last: Throwable? = null
        for (idx in start until chain.size) {
            val model = chain[idx]
            var attempts = 0
            while (true) {
                try {
                    val obj = request(key, model, parts)
                    lastModelUsed = model
                    return obj to idx
                } catch (e: GeminiHttpException) {
                    last = e
                    if (e.message?.contains("API key", ignoreCase = true) == true) throw e   // مفتاح خاطئ: لا فائدة من التجربة
                    if (e.code == 429 && attempts < 2) { attempts++; delay(6000); continue }
                    break
                } catch (e: JSONException) {
                    last = e
                    break
                }
            }
        }
        throw last ?: IllegalStateException("No Gemini model available")
    }

    // ---------------- التعرف على الكلام بـ Gemini (الأدق للهجات) ----------------
    /**
     * يرسل الصوت (مقاطع ~60 ثانية، WAV 16kHz) إلى Gemini ويطلب نصاً مقسماً مع أزمنة.
     * languageName مثل "Egyptian Arabic (colloquial dialect)". الأزمنة تقريبية (يحددها النموذج).
     */
    suspend fun transcribeAudio(
        apiKey: String, preferredModel: String?, languageName: String, pcmFile: File, onProgress: (Int) -> Unit = {}
    ): Result<List<SpeechSegment>> = withContext(Dispatchers.IO) {
        try {
            val key = apiKey.trim()
            require(key.isNotBlank()) { tr("أدخل مفتاح Gemini API أولاً", "Enter a Gemini API key first") }
            val total = pcmFile.length()
            if (total <= 0) return@withContext Result.success(emptyList())
            val chain = buildChain(key, preferredModel)
            val ranges = PcmUtils.splitRanges(pcmFile, total, 60)
            val out = mutableListOf<SpeechSegment>()
            var start = 0
            val prompt = "Transcribe this audio exactly as spoken. Language: $languageName. " +
                "Write the words in the original script as they are actually said; keep the dialect and colloquial wording (do NOT convert dialect to Modern Standard Arabic and do NOT translate). " +
                "Split the speech into subtitle segments of at most 10 words each. " +
                "Return valid JSON only: {\"segments\":[{\"start\":0.0,\"end\":2.5,\"text\":\"...\"}]} " +
                "where start and end are in seconds from the beginning of THIS audio clip. " +
                "If there is no speech return {\"segments\":[]}. Do not invent words, do not add markdown, do not add commentary."
            ranges.forEachIndexed { i, (s, e) ->
                coroutineContext.ensureActive()
                if (!PcmUtils.isSilent(pcmFile, s, e)) {
                    val wav = File.createTempFile("gemini_chunk_", ".wav")
                    try {
                        PcmUtils.writeWav(pcmFile, s, e, wav)
                        val b64 = Base64.encodeToString(wav.readBytes(), Base64.NO_WRAP)
                        val parts = JSONArray()
                            .put(JSONObject().put("text", prompt))
                            .put(JSONObject().put("inline_data", JSONObject().put("mime_type", "audio/wav").put("data", b64)))
                        val (parsed, used) = callWithFallback(key, chain, start, parts)
                        start = used
                        val offset = s * 1000 / PcmUtils.BYTES_PER_SEC
                        val chunkMs = (e - s) * 1000 / PcmUtils.BYTES_PER_SEC
                        val arr = parsed.optJSONArray("segments") ?: JSONArray()
                        for (j in 0 until arr.length()) {
                            val item = arr.optJSONObject(j) ?: continue
                            val text = item.optString("text", "").trim()
                            if (text.isBlank()) continue
                            val st = (secs(item.opt("start")) * 1000).toLong().coerceIn(0, chunkMs)
                            var en = (secs(item.opt("end")) * 1000).toLong().coerceIn(0, chunkMs + 2000)
                            if (en <= st) en = st + 1500
                            out.add(SpeechSegment(text, offset + st, offset + en))
                        }
                    } finally { runCatching { wav.delete() } }
                }
                onProgress((((i + 1) * 100) / ranges.size).coerceIn(0, 99))
            }
            onProgress(100)
            Result.success(out.sortedBy { it.startMs })
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            Result.failure(e)
        }
    }

    /** يقبل رقماً أو نصاً مثل "0:03.5" ويعيد ثواني */
    private fun secs(v: Any?): Double = when (v) {
        is Number -> v.toDouble()
        is String -> {
            val p = v.trim().split(":")
            try { p.fold(0.0) { acc, x -> acc * 60 + x.toDouble() } } catch (e: Exception) { 0.0 }
        }
        else -> 0.0
    }

    // ---------------- شبكة ----------------
    private fun httpGet(url: String, key: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000; c.readTimeout = 30000
        c.setRequestProperty("x-goog-api-key", key)
        try {
            val status = c.responseCode
            val raw = (if (status in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (status !in 200..299) throw GeminiHttpException(status, "Gemini HTTP $status: " + errorMessage(raw))
            return raw
        } finally { c.disconnect() }
    }

    private fun errorMessage(raw: String): String =
        runCatching { JSONObject(raw).optJSONObject("error")?.optString("message") }.getOrNull()?.takeIf { it.isNotBlank() } ?: raw.take(300)

    private fun request(key: String, model: String, parts: JSONArray, jsonMime: Boolean = true): JSONObject {
        val conn = (URL("$BASE/models/$model:generateContent").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 90000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("x-goog-api-key", key)
        }
        try {
            val gen = JSONObject().put("temperature", 0.1)
            if (jsonMime) gen.put("responseMimeType", "application/json")
            val body = JSONObject()
                .put("contents", JSONArray().put(JSONObject().put("parts", parts)))
                .put("generationConfig", gen)
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val status = conn.responseCode
            val raw = (if (status in 200..299) conn.inputStream else conn.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (status !in 200..299) {
                val msg = errorMessage(raw)
                // بعض النماذج لا تدعم وضع JSON الصريح: نعيد المحاولة بدونه
                if (status == 400 && jsonMime && (msg.contains("mime", true) || msg.contains("JSON mode", true))) {
                    return request(key, model, parts, false)
                }
                throw GeminiHttpException(status, "Gemini HTTP $status: $msg")
            }
            val outParts = JSONObject(raw).optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
            val sb = StringBuilder()
            if (outParts != null) for (i in 0 until outParts.length()) {
                val part = outParts.optJSONObject(i) ?: continue
                if (part.optBoolean("thought", false)) continue          // نتجاهل أجزاء "التفكير"
                sb.append(part.optString("text", ""))
            }
            val text = sb.toString().trim()
            if (text.isBlank()) throw GeminiHttpException(200, "Gemini returned an empty response")
            val start = text.indexOf('{')
            val end = text.lastIndexOf('}')
            if (start < 0 || end <= start) throw JSONException("No JSON object in Gemini response")
            return JSONObject(text.substring(start, end + 1))
        } finally {
            conn.disconnect()
        }
    }
}
